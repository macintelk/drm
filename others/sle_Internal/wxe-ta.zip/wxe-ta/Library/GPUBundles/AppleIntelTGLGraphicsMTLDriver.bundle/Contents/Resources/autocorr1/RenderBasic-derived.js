// Formulae to compute derived counters from raw counter values

function GpuTime()
{
    return GpuTimeMD;
}

function GpuCoreClocks()
{
    return GpuCoreClocksMD;
}

function AvgGpuCoreFrequencyMHz()
{
    return AvgGpuCoreFrequencyMHzMD;
}

function VsThreads()
{
    return VsThreadsMD;
}

function HsThreads()
{
    return HsThreadsMD;
}

function DsThreads()
{
    return DsThreadsMD;
}

function GsThreads()
{
    return GsThreadsMD;
}

function PsThreads()
{
    return PsThreadsMD;
}

function CsThreads()
{
    return CsThreadsMD;
}

function GpuBusy()
{
    return GpuBusyMD;
}

function EuActive()
{
    return EuActiveMD;
}

function EuStall()
{
    return EuStallMD;
}

function EuFpuBothActive()
{
    return EuFpuBothActiveMD;
}

function VsFpu0Active()
{
    return VsFpu0ActiveMD;
}

function VsFpu1Active()
{
    return VsFpu1ActiveMD;
}

function VsSendActive()
{
    return VsSendActiveMD;
}

function VsEuActive()
{
    return VsEuActiveMD;
}

function VsEuActivePerThread()
{
    return VsEuActivePerThreadMD;
}

function VsEuStallPerThread()
{
    return VsEuStallPerThreadMD;
}

function VsEuStall()
{
    return VsEuStallMD;
}

function PsFpu0Active()
{
    return PsFpu0ActiveMD;
}

function PsFpu1Active()
{
    return PsFpu1ActiveMD;
}

function PsSendActive()
{
    return PsSendActiveMD;
}

function PsEuBothFpuActive()
{
    return PsEuBothFpuActiveMD;
}

function PsEuActive()
{
    return PsEuActiveMD;
}

function PsEuActivePerThread()
{
    return PsEuActivePerThreadMD;
}

function PsEuStallPerThread()
{
    return PsEuStallPerThreadMD;
}

function PsEuStall()
{
    return PsEuStallMD;
}

function Sampler0Busy()
{
    return Sampler0BusyMD;
}

function Sampler1Busy()
{
    return Sampler1BusyMD;
}

function SamplersBusy()
{
    return SamplersBusyMD;
}

function Sampler0Bottleneck()
{
    return Sampler0BottleneckMD;
}

function Sampler1Bottleneck()
{
    return Sampler1BottleneckMD;
}

function RasterizedPixels()
{
    return RasterizedPixelsMD;
}

function HiDepthTestFails()
{
    return HiDepthTestFailsMD;
}

function EarlyDepthTestFails()
{
    return EarlyDepthTestFailsMD;
}

function SamplesKilledInPs()
{
    return SamplesKilledInPsMD;
}

function PixelsFailingPostPsTests()
{
    return PixelsFailingPostPsTestsMD;
}

function SamplesWritten()
{
    return SamplesWrittenMD;
}

function SamplesBlended()
{
    return SamplesBlendedMD;
}

function SamplerTexels()
{
    return SamplerTexelsMD;
}

function SamplerTexelMisses()
{
    return SamplerTexelMissesMD;
}

function SamplerL1Misses()
{
    return SamplerL1MissesMD;
}

function SlmBytesRead()
{
    return SlmBytesReadMD;
}

function SlmBytesWritten()
{
    return SlmBytesWrittenMD;
}

function ShaderMemoryAccesses()
{
    return ShaderMemoryAccessesMD;
}

function ShaderAtomics()
{
    return ShaderAtomicsMD;
}

function L3Lookups()
{
    return L3LookupsMD;
}

function L3Misses()
{
    return L3MissesMD;
}

function L3SamplerThroughput()
{
    return L3SamplerThroughputMD;
}

function L3ShaderThroughput()
{
    return L3ShaderThroughputMD;
}

function ShaderBarriers()
{
    return ShaderBarriersMD;
}

function GtiVfThroughput()
{
    return GtiVfThroughputMD;
}

function GtiDepthThroughput()
{
    return GtiDepthThroughputMD;
}

function GtiRccThroughput()
{
    return GtiRccThroughputMD;
}

function GtiL3Throughput()
{
    return GtiL3ThroughputMD;
}

function GtiReadThroughput()
{
    return GtiReadThroughputMD;
}

function GtiWriteThroughput()
{
    return GtiWriteThroughputMD;
}

function SamplerBottleneck()
{
    return SamplerBottleneckMD;
}

